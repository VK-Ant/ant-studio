<p align="center">
  <img src="https://raw.githubusercontent.com/VK-Ant/ant-studio/main/assets/hero.png" alt="Ant Studio" width="70%">
</p>

<p align="center">
  <em>One command, Real results,  Quality scored, Privacy audited.</em>
</p>

<p align="center">
  <a href="https://pypi.org/project/antstudio/"><img src="https://img.shields.io/pypi/v/antstudio?color=orange&style=for-the-badge" alt="PyPI"></a>
  <a href="#"><img src="https://img.shields.io/badge/python-3.9+-blue?style=for-the-badge" alt="Python"></a>
  <a href="#"><img src="https://img.shields.io/badge/license-Apache%202.0-blue?style=for-the-badge" alt="License"></a>
</p>

---

## What is Ant Studio?

Ant Studio is a CLI + Python tool that solves AI problems in one command. Extract fields from 1000 PDFs. Forecast time-series. Detect anomalies. Ask questions about documents. Every command automatically includes quality scoring (78 metrics) and privacy auditing.

Not a framework. Not a platform. A tool like `ffmpeg` for media or `curl` for HTTP.

```bash
pip install antstudio
antstudio doc extract ./invoices/ --fields vendor,amount,date --output results.csv
```

---

## Quick Start

```bash
pip install antstudio

# Extract from documents (PDF, DOCX, Excel, images, TXT)
antstudio doc extract ./invoices/ --fields vendor,amount --output results.csv

# Ask questions about documents
antstudio doc ask ./report.pdf "What is the total revenue?"

# Forecast time-series
antstudio ts forecast ./sales.csv --target revenue --horizon 30

# Detect anomalies
antstudio ts anomaly ./sensors.csv --target temperature --method zscore
```

Every command auto-runs: **Adaptive Intelligence** (routing) + **llmevalkit** (quality) + **AntGuard** (privacy).

---

## How It Works

```
$ antstudio doc extract ./invoices/ --fields vendor,amount --output results.csv

  Ant Studio v0.1.0 | DocQWise + llmevalkit + AntGuard

  [1/4] Scanning .................... 47 files found
  [2/4] Extracting .................. 47/47 complete
  [3/4] Quality (llmevalkit) ........ 44 passed, 3 flagged
  [4/4] Privacy (AntGuard) .......... data_left: NO | risk: LOW

  Results saved: results.csv (47 rows)
  Flagged items: results_flagged.csv (3 rows)

  Pipeline: Document Extraction [a1b2c3d4]
  ============================================================
  [+] Scan Input                        0ms
      |
      v
  [+] Extract Fields                   456ms
      |
      v
  [+] Quality Check                      1ms   q:0.94
      |
      v
  [+] Privacy Audit                      0ms
  ============================================================
  4/4 passed | 457ms total | Status: SUCCESS
```

---

## Input Sources

Ant Studio reads from **any source**:

```bash
# Local file (PDF, DOCX, Excel, CSV, TXT, images)
antstudio doc extract ./invoice.pdf

# Local folder (batch 1000+ files, recursive)
antstudio doc extract ./invoices/

# Specific file types from folder
antstudio doc extract ./mixed_docs/ --extensions .pdf,.docx,.xlsx,.png

# Network drive / NAS
antstudio doc extract /mnt/nas/documents/
antstudio doc extract Z:\SharedDocs\

# Database
antstudio doc extract --db "postgresql://user:pass@host/db" --query "SELECT * FROM docs"
antstudio doc extract --db "sqlite:///data/invoices.db" --query "SELECT text FROM pending"

# URL
antstudio doc extract --url "https://example.com/report.pdf"
```

**Supported file types:** PDF, DOCX, XLSX/XLS, CSV, TXT, MD, JSON, XML, HTML, PNG, JPG, JPEG, BMP, TIFF (images via OCR)

---

## Output Destinations

Results go **anywhere**:

```bash
# Local files
antstudio doc extract ./invoices/ --output results.csv
antstudio doc extract ./invoices/ --output results.xlsx
antstudio doc extract ./invoices/ --output results.json

# Database
antstudio doc extract ./invoices/ --output-db "postgresql://user:pass@host/db" --table extracted

# Cloud (coming)
antstudio doc extract ./invoices/ --output-azure "connection_string" --container results
antstudio doc extract ./invoices/ --output-s3 my-bucket --path output/
antstudio doc extract ./invoices/ --output-webhook "https://api.example.com/results"
```

---

## Python SDK

Same engine, in code:

```python
from antstudio.doc.extract import run as extract
from antstudio.doc.ask import run as ask
from antstudio.ts.forecast import run as forecast
from antstudio.ts.anomaly import run as detect

# Extract from folder of any file type
results = extract("./invoices/", fields=["vendor", "amount", "date"])
results.to_csv("output.csv")
results.to_excel("output.xlsx")
results.to_database("postgresql://...", table="results")
print(results.quality)     # llmevalkit scores
print(results.audit)       # AntGuard report

# Forecast
fc = forecast("./sales.csv", target="revenue", horizon=30)
fc.to_csv("forecast.csv")
fc.save_chart("chart.png")

# Anomaly detection
anom = detect("./sensors.csv", target="temperature", method="zscore")
anom.to_csv("anomalies.csv")

# Document Q&A
answer = ask("./report.pdf", "What are the payment terms?", rag="auto")
print(answer.text, answer.confidence)
```

---

## Pipeline Tracking

Every command creates a tracked pipeline run:

```bash
# List all past runs
antstudio runs

  ID         Pipeline                                 Steps        Status     Time
  ────────── ──────────────────────────────────────── ──────────── ────────── ────────
  a1b2c3d4   Document Extraction: ./invoices/         4/4 passed   success    12.3s
  e5f6g7h8   Forecast: ./sales.csv                    3/3 passed   success    3.1s
  i9j0k1l2   Anomaly Detection: ./sensors.csv         3/3 passed   success    0.5s

# Show detailed step-by-step view
antstudio run-detail a1b2c3d4

  Pipeline: Document Extraction [a1b2c3d4]
  Status: SUCCESS | 12.3s | 2026-09-05T10:30:00
  ============================================================
  [+] Scan Input                        15ms
      |
      v
  [+] Extract Fields                  11800ms
      |
      v
  [+] Quality Check                      1ms
      |
      v
  [+] Privacy Audit                      0ms
  ============================================================
  4/4 steps passed
```

---

## Responsible AI — Always On

Three pillars run on **every command**. Never configured. Never skipped.

| Pillar | Library | What It Does |
|--------|---------|-------------|
| **Routing** | Adaptive Intelligence | Auto-detects file type, routes to correct pipeline |
| **Quality** | llmevalkit (78 metrics) | Scores every output. Flags low confidence. |
| **Privacy** | AntGuard | Monitors file/network. Proves data stayed local. |

```
Every command output includes:
  Quality: 44 passed, 3 flagged
  Privacy: data_left: NO | risk: LOW
```

---

## All Commands

```bash
# Document Intelligence
antstudio doc extract <source> [options]    # Extract fields from documents
antstudio doc ask <source> "question"       # Ask questions about documents

# Temporal Intelligence
antstudio ts forecast <source> [options]    # Forecast time-series
antstudio ts anomaly <source> [options]     # Detect anomalies

# Pipeline Tracking
antstudio runs                              # List all pipeline runs
antstudio run-detail <run_id>               # Detailed step-by-step view
antstudio history                           # Execution history with quality scores

# System
antstudio models                            # List Ollama models
antstudio status                            # Library + system status
```

---

## Ant Intelligence Ecosystem

| Library | Domain | Tagline |
|---------|--------|---------|
| [DocQWise](https://pypi.org/project/docqwise/) | Documents | Read. Extract. Retrieve. |
| [WavQWise](https://pypi.org/project/wavqwise/) | Temporal | Sense. Forecast. Alert. |
| [SightRAG](https://pypi.org/project/sightrag/) | Vision | See. Search. Retrieve. |
| [SonarWise](https://pypi.org/project/sonarwise/) | Audio | Hear. Search. Retrieve. |
| [Adaptive Intelligence](https://pypi.org/project/adaptive-intelligence/) | Routing | Learn. Remember. Adapt. |
| [llmevalkit](https://pypi.org/project/llmevalkit/) | Quality | Evaluate. Score. Improve. |
| [AntGuard](https://pypi.org/project/antguard/) | Privacy | Guard. Detect. Protect. |

---

## Testing

```bash
pip install pytest
python -m pytest tests/ -v
```

---

## License

Apache 2.0

---

<p align="center">
  <img src="assets/logo.png" alt="Ant Studio" width="100">
  <br>
  <b><a href="https://github.com/VK-Ant/ant-studio">Venkatkumar Rajan</a></b> — One ecosystem. Limitless possibilities.
</p>
